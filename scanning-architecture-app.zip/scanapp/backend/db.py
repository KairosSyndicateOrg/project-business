"""
Local data model, following spec §4, extended with a `category` column on
Product and a Sale / SaleItem pair for the consumer-GUI checkout flow.

Product
ProductReferenceImage  (embedding_vector kept separate from image_path so the
                         ANN index (§3.4) can load vectors without touching
                         image blobs)
ScanLog
StockEvent (§7.1 — write-target for confirmed scans and sales)
Sale / SaleItem — one checkout = one Sale + N SaleItem rows; finalizing a
                  checkout also writes matching StockEvent rows so both
                  views of "what happened" stay in sync.
"""

import sqlite3
import json
import uuid
import time
import threading
from contextlib import contextmanager

from . import config

_local = threading.local()

SCHEMA = """
CREATE TABLE IF NOT EXISTS product (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    brand TEXT,
    size_variant TEXT,
    price REAL,
    stock_qty INTEGER DEFAULT 0,
    qr_enabled INTEGER DEFAULT 0,
    category TEXT,
    last_image_update_at REAL
);

CREATE TABLE IF NOT EXISTS product_reference_image (
    id TEXT PRIMARY KEY,
    product_id TEXT NOT NULL REFERENCES product(id) ON DELETE CASCADE,
    angle_label TEXT,                 -- front/back/left/right
    image_path TEXT,
    embedding_vector TEXT,            -- JSON list[float], quantized in production
    ocr_text_raw TEXT,
    created_at REAL
);

CREATE TABLE IF NOT EXISTS scan_log (
    id TEXT PRIMARY KEY,
    timestamp REAL,
    matched_product_id TEXT,
    match_path TEXT,                  -- qr / auto_fused / candidate_pick / manual_new
    final_score REAL,
    resolved_by_user INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS stock_event (
    id TEXT PRIMARY KEY,
    product_id TEXT REFERENCES product(id),
    event_type TEXT,                  -- scan_in / scan_out / manual_adjustment / sale
    quantity_delta INTEGER,
    timestamp REAL,
    source TEXT                       -- scan / manual
);

CREATE TABLE IF NOT EXISTS sale (
    id TEXT PRIMARY KEY,
    timestamp REAL,
    total REAL,
    item_count INTEGER
);

CREATE TABLE IF NOT EXISTS sale_item (
    id TEXT PRIMARY KEY,
    sale_id TEXT NOT NULL REFERENCES sale(id) ON DELETE CASCADE,
    product_id TEXT REFERENCES product(id),
    name_snapshot TEXT,               -- copy of product name at sale time
    price_snapshot REAL,              -- copy of unit price at sale time
    quantity INTEGER
);

CREATE INDEX IF NOT EXISTS idx_ref_image_product ON product_reference_image(product_id);
CREATE INDEX IF NOT EXISTS idx_scan_log_product ON scan_log(matched_product_id);
CREATE INDEX IF NOT EXISTS idx_sale_item_sale ON sale_item(sale_id);
"""


def get_conn():
    if not hasattr(_local, "conn"):
        _local.conn = sqlite3.connect(config.DB_PATH)
        _local.conn.row_factory = sqlite3.Row
        _local.conn.execute("PRAGMA foreign_keys = ON")
    return _local.conn


def _migrate(conn):
    """Add columns/tables introduced after a DB may already exist on disk."""
    cols = [r["name"] for r in conn.execute("PRAGMA table_info(product)").fetchall()]
    if "category" not in cols:
        conn.execute("ALTER TABLE product ADD COLUMN category TEXT")


def init_db():
    conn = get_conn()
    conn.executescript(SCHEMA)
    _migrate(conn)
    conn.commit()


@contextmanager
def cursor():
    conn = get_conn()
    cur = conn.cursor()
    try:
        yield cur
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()


# ---------- Product ----------

def add_product(name, brand="", size_variant="", price=0.0, qr_enabled=False,
                 category="", initial_stock=0):
    pid = str(uuid.uuid4())
    with cursor() as cur:
        cur.execute(
            "INSERT INTO product (id, name, brand, size_variant, price, stock_qty, qr_enabled, category, last_image_update_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (pid, name, brand, size_variant, price, int(initial_stock), int(qr_enabled), category, time.time()),
        )
    if initial_stock:
        with cursor() as cur:
            cur.execute(
                "INSERT INTO stock_event (id, product_id, event_type, quantity_delta, timestamp, source) "
                "VALUES (?, ?, 'manual_adjustment', ?, ?, 'manual')",
                (str(uuid.uuid4()), pid, int(initial_stock), time.time()),
            )
    return pid


def get_product(product_id):
    with cursor() as cur:
        cur.execute("SELECT * FROM product WHERE id = ?", (product_id,))
        row = cur.fetchone()
        return dict(row) if row else None


def list_products():
    with cursor() as cur:
        cur.execute("SELECT * FROM product ORDER BY name")
        return [dict(r) for r in cur.fetchall()]


def adjust_stock(product_id, delta, event_type="scan_in", source="scan"):
    with cursor() as cur:
        cur.execute("UPDATE product SET stock_qty = stock_qty + ? WHERE id = ?", (delta, product_id))
        cur.execute(
            "INSERT INTO stock_event (id, product_id, event_type, quantity_delta, timestamp, source) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (str(uuid.uuid4()), product_id, event_type, delta, time.time(), source),
        )


# ---------- ProductReferenceImage ----------

def add_reference_image(product_id, angle_label, image_path, embedding_vector, ocr_text_raw=""):
    rid = str(uuid.uuid4())
    with cursor() as cur:
        cur.execute(
            "INSERT INTO product_reference_image "
            "(id, product_id, angle_label, image_path, embedding_vector, ocr_text_raw, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (rid, product_id, angle_label, image_path, json.dumps(embedding_vector), ocr_text_raw, time.time()),
        )
        cur.execute("UPDATE product SET last_image_update_at = ? WHERE id = ?", (time.time(), product_id))
    return rid


def all_reference_vectors():
    """Returns list of (product_id, embedding_vector: list[float]) for the ANN/flat index (§3.4)."""
    with cursor() as cur:
        cur.execute("SELECT product_id, embedding_vector FROM product_reference_image")
        out = []
        for row in cur.fetchall():
            vec = json.loads(row["embedding_vector"]) if row["embedding_vector"] else []
            out.append((row["product_id"], vec))
        return out


def reference_ocr_texts():
    """Returns product dicts (id, name, brand) used for fuzzy-name matching (§3.2)."""
    with cursor() as cur:
        cur.execute(
            "SELECT DISTINCT p.id as id, p.name, p.brand "
            "FROM product p"
        )
        return [dict(r) for r in cur.fetchall()]


def find_product_by_qr_id(qr_payload):
    """QR payload is `shopid:sku_uuid` (§3.1) — here we just treat the UUID part as product id."""
    pid = qr_payload.split(":")[-1]
    return get_product(pid)


# ---------- ScanLog ----------

def log_scan(matched_product_id, match_path, final_score, resolved_by_user=False):
    sid = str(uuid.uuid4())
    with cursor() as cur:
        cur.execute(
            "INSERT INTO scan_log (id, timestamp, matched_product_id, match_path, final_score, resolved_by_user) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (sid, time.time(), matched_product_id, match_path, final_score, int(resolved_by_user)),
        )
    return sid


def recent_scan_logs(limit=50):
    with cursor() as cur:
        cur.execute("SELECT * FROM scan_log ORDER BY timestamp DESC LIMIT ?", (limit,))
        return [dict(r) for r in cur.fetchall()]


# ---------- Sale / checkout ----------

def create_sale(cart_items):
    """
    cart_items: list of {"product_id", "quantity"} (quantity is however many
    units the shopkeeper scanned/added during this checkout).

    Writes one Sale row, one SaleItem row per line, decrements stock, and
    writes a matching StockEvent per line so ScanLog/StockEvent stay the
    single source of truth for "what happened" while Sale/SaleItem is the
    friendlier read-shape for an invoice.

    Returns the invoice dict: {id, timestamp, items: [...], total}.
    """
    sale_id = str(uuid.uuid4())
    ts = time.time()
    total = 0.0
    line_items = []

    with cursor() as cur:
        cur.execute(
            "INSERT INTO sale (id, timestamp, total, item_count) VALUES (?, ?, 0, 0)",
            (sale_id, ts),
        )
        for entry in cart_items:
            product = get_product(entry["product_id"])
            if not product:
                continue
            qty = int(entry.get("quantity", 1))
            if qty <= 0:
                continue
            price = float(product.get("price") or 0.0)
            line_total = price * qty
            total += line_total

            cur.execute(
                "INSERT INTO sale_item (id, sale_id, product_id, name_snapshot, price_snapshot, quantity) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (str(uuid.uuid4()), sale_id, product["id"], product["name"], price, qty),
            )
            cur.execute("UPDATE product SET stock_qty = stock_qty - ? WHERE id = ?", (qty, product["id"]))
            cur.execute(
                "INSERT INTO stock_event (id, product_id, event_type, quantity_delta, timestamp, source) "
                "VALUES (?, ?, 'sale', ?, ?, 'scan')",
                (str(uuid.uuid4()), product["id"], -qty, ts),
            )
            line_items.append({
                "product_id": product["id"], "name": product["name"],
                "price": price, "quantity": qty, "line_total": line_total,
            })

        cur.execute(
            "UPDATE sale SET total = ?, item_count = ? WHERE id = ?",
            (total, sum(li["quantity"] for li in line_items), sale_id),
        )

    return {"id": sale_id, "timestamp": ts, "items": line_items, "total": total}


def today_sales_summary():
    """Revenue + units sold since local midnight, for the Inventory tab's sales strip."""
    midnight = time.time() - (time.time() % 86400)  # coarse UTC-day boundary; fine for a shop-hours summary
    with cursor() as cur:
        cur.execute(
            "SELECT COALESCE(SUM(total),0) as revenue, COALESCE(SUM(item_count),0) as units "
            "FROM sale WHERE timestamp >= ?",
            (midnight,),
        )
        row = cur.fetchone()
        return {"revenue": row["revenue"], "units": row["units"]}


def recent_sales(limit=20):
    with cursor() as cur:
        cur.execute("SELECT * FROM sale ORDER BY timestamp DESC LIMIT ?", (limit,))
        return [dict(r) for r in cur.fetchall()]
